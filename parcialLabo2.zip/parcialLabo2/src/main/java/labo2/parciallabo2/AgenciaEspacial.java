/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labo2.parciallabo2;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author aledesma
 */
public class AgenciaEspacial {
    private String nombre;
    private List<Nave> naves;
    
    
    public AgenciaEspacial(String nombre){
        this.nombre=nombre;
        naves = new ArrayList();
    }
    
    public Nave buscarNave(Nave naveBuscada)
{
    for(Nave naveLista : naves)
    {
        if(naveLista.equals(naveBuscada))
        {
            return naveLista;
        }
    }

    return null;
}
    
    public void agregarNave(Nave nave){
        if(nave!=null){
            if (buscarNave(nave)!=null)
            {
               throw new NaveDuplicadaException(); 
            }
           naves.add(nave);
        }
    }
    
    public void mostrarNaves(){
        for(Nave nave: naves ){
         System.out.println(nave.toString());
    }       
    }
    
    public boolean iniciarExploracion() {
    boolean algunaNaveExploro = false;

    for (Nave nave : naves) {
        if (nave instanceof Exploradoras) {
            ((Exploradoras) nave).explorar();
            algunaNaveExploro = true;
        } else {
            System.out.println(nave.toString() + " no puede explorar");
        }
    }

    return algunaNaveExploro;
}
    
}
