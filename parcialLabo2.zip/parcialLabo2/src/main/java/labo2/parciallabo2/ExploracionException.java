/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labo2.parciallabo2;

/**
 *
 * @author aledesma
 */
public class ExploracionException extends Exception {
    public ExploracionException(String message) {
        super(message);
    }

    
    public ExploracionException(String message, Throwable cause) {
        super(message, cause);
    }
}