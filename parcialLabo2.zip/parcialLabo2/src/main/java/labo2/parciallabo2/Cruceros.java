/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labo2.parciallabo2;

/**
 *
 * @author aledesma
 */
public class Cruceros extends Nave{
    
   private int capPasajeros;
    
    public Cruceros(String nombre,int capacidadTripulacion,int lanzamiento, int capPasajeros){   
        super(nombre,capacidadTripulacion,lanzamiento);
       this.capPasajeros=capPasajeros;
    }
    
    
     @Override
    public String toString() {
        return "Cruceros{" + "nombre=" + nombre + ", capacidadTripulacion=" + capacidadTripulacion + ", lanzamiento=" + lanzamiento +", capPasajeros=" +capPasajeros+'}';
    }
    
    
    
    
    
}
