/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labo2.parciallabo2;

/**
 *
 * @author aledesma
 */
public class Cargueros extends Nave implements Exploradoras {
    
    private int capCarga;
    private  static final int capCargaMAX=500;
    private  static final int capCargaMIN=100;
    
   public Cargueros(String nombre, int capacidadTripulacion, int lanzamiento, int capCarga) {
        super(nombre, capacidadTripulacion, lanzamiento);

        if (capCarga < capCargaMIN || capCarga > capCargaMAX) {
            throw new IllegalArgumentException("La capacidad de carga debe estar entre 100 y 500.");
        } else {
            this.capCarga = capCarga;
        }
    }
    
    
    public boolean explorar(){
        return true;
    }
    
    
     @Override
    public String toString() {
        return "Cargueros{" + "nombre=" + nombre + ", capacidadTripulacion=" + capacidadTripulacion + ", lanzamiento=" + lanzamiento +", capCarga=" +capCarga+'}';
    }
    
}
