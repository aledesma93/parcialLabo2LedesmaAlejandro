/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labo2.parciallabo2;

import java.util.Objects;

/**
 *
 * @author aledesma
 */
public abstract class Nave {
     protected String nombre;
    protected int capacidadTripulacion;
    protected int lanzamiento;

    public Nave(String nombre, int capacidadTripulacion, int lanzamiento) {
        this.nombre = nombre;
        this.capacidadTripulacion = capacidadTripulacion;
        this.lanzamiento = lanzamiento;
       
    }

    @Override
    public String toString() {
        return "Nave{" + "nombre=" + nombre + ", capacidadTripulacion=" + capacidadTripulacion + ", lanzamiento=" + lanzamiento + '}';
    }

   
   
 
    
    
    @Override
    public boolean equals( Object o){
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Nave nave = (Nave)o;
        return Objects.equals(nombre, nave.nombre)&& Objects.equals(lanzamiento, nave.lanzamiento);
    }
    
    
    
}


