/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labo2.parciallabo2;

/**
 *
 * @author aledesma
 */
public class NaveDuplicadaException extends RuntimeException {
    private static final String MESSAGE="esta nave ya esta ingresada";
    
   public NaveDuplicadaException(){
       super(MESSAGE);
   } 
}


