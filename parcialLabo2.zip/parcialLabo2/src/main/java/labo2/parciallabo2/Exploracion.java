/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labo2.parciallabo2;

/**
 *
 * @author aledesma
 */
public class Exploracion  extends Nave implements Exploradoras {
    
    private Mision mision;
    
    public Exploracion(String nombre,int capacidadTripulacion,int lanzamiento, Mision mision){   
        super(nombre,capacidadTripulacion,lanzamiento);
        this.mision=mision;
    }
    
    public boolean explorar(){
        return true;
    }
    
     @Override
    public String toString() {
        return "Exploracion{" + "nombre=" + nombre + ", capacidadTripulacion=" + capacidadTripulacion + ", lanzamiento=" + lanzamiento +", mision=" +mision+'}';
    }
    
}
