/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package labo2.parciallabo2;

/**
 *
 * @author aledesma
 */
public class ParcialLabo2 {

    public static void main(String[] args) {
    // Crear la agencia espacial
    AgenciaEspacial agencia = new AgenciaEspacial("pepe");

    // Agregar naves, encapsulando en un try-catch para manejar excepciones
    try {
        agencia.agregarNave(new Exploracion("nave1", 2000, 2024, Mision.EXPLORACION));
        agencia.agregarNave(new Exploracion("nave2", 1000, 2025, Mision.CARTOGRAFIA));
        agencia.agregarNave(new Cruceros("nave3", 1000, 2025, 40000));
        // Nave con capacidad de carga inválida, generará una excepción
        agencia.agregarNave(new Cargueros("nave3", 1000, 2025, 40000));
        // Nave duplicada, generará una excepción personalizada
        agencia.agregarNave(new Exploracion("nave2", 1000, 2025, Mision.CARTOGRAFIA));
    } catch (IllegalArgumentException e) {
        System.err.println("Error al agregar la nave: " + e.getMessage());
    } catch (NaveDuplicadaException e) {
        System.err.println("La nave ya existe: " + e.getMessage());
    }

        // Iniciar la exploración
        agencia.iniciarExploracion();

    // Mostrar las naves
    agencia.mostrarNaves();
}
}
